/*
	Copyright (c) 2004-2006, The Dojo Foundation
	All Rights Reserved.

	Licensed under the Academic Free License version 2.1 or above OR the
	modified BSD license. For more information on Dojo licensing, see:

		http://dojotoolkit.org/community/licensing.shtml
*/



({"displayName":"\u091c\u093e\u092a\u093e\u0928\u0940 \u092f\u0947\u0928", "symbol":"\xa5"})
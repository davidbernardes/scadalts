/*
	Copyright (c) 2004-2006, The Dojo Foundation
	All Rights Reserved.

	Licensed under the Academic Free License version 2.1 or above OR the
	modified BSD license. For more information on Dojo licensing, see:

		http://dojotoolkit.org/community/licensing.shtml
*/



({"rangeMessage":"* \u8f93\u5165\u6570\ufffd?\ufffd\u8d85\u51fa\u503c\u57df\u3002", "invalidMessage":"* \ufffd?\ufffd\u6cd5\u7684\u8f93\u5165\u503c\u3002", "missingMessage":"* \u6b64\u503c\u662f\u5fc5\u987b\u7684\u3002"})